package com.menisamet.totake.Server.Listeners;

import com.menisamet.totake.Modals.User;

/**
 * Created by meni on 05/06/17.
 */

public interface UserLoadListener {
    public void onUserLoad(User user);
}
