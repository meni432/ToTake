package com.menisamet.totake.Server.Interfaces;

import java.util.Date;

/**
 * Created by meni on 16/04/17.
 */

public interface TripInterface {
    public String getDestinationName();
    public Date getStartDate();
    public Date getEndDate();
}
