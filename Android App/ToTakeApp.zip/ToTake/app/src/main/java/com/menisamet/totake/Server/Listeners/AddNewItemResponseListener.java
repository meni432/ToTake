package com.menisamet.totake.Server.Listeners;

import com.menisamet.totake.Modals.Item;

/**
 * Created by tahel on 25/04/2017.
 */

public interface AddNewItemResponseListener {
    public void onResponse(Item item);
}
